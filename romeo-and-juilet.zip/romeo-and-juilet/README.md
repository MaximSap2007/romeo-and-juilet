# Romeo and Juilet

A Pen created on CodePen.io. Original URL: [https://codepen.io/Maxim-Sapozhnikov-MaximSap/pen/ZEZLBaz](https://codepen.io/Maxim-Sapozhnikov-MaximSap/pen/ZEZLBaz).

